<?php
namespace app\index\controller;
use app\index\controller\Base;
use app\index\model\ListId as ListIdModel;

class ListId extends Base
{
	public function _initialize()
	{
		parent::_initialize();
		$cs = model('list_id')->getTree();
		$this->assign('cs', $cs);
	}

	public function index()
	{
		return $this->fetch();
	}

	public function add()
	{
		return $this->fetch();
	}

	public function doAdd()
	{
		$data = request()->param();
		
		$stmt = model('list_id')->save($data);

		if ($stmt) {
			return $this->success('添加分类成功', url('index/ListId/add'));
		} else {
			return $this->success('添加分类失败', url('index/ListId/add'));
		}
		
	}

	public function del()
	{
		$id 	= request()->param()['id'];
		$data	= db('list_id')->where('list_id', $id)->update(['level'=>1]);
		if ($data) {
			return $this->success('删除分类成功', url('index/ListId/index'));
		} else {
			return $this->success('删除分类失败', url('index/ListId/index'));
		}
		
	}

}