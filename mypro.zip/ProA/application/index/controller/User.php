<?php
namespace app\index\controller;
use think\Controller;
use think\Request;

class User extends Controller
{
	//用户登录页
	public function login()
	{
		return $this->fetch();

	}
	//用户登录验证
	public function doLogin()
	{
		$data = request()->param();
		if (!captcha_check($data['captcha'])) {
			$this->error('验证码非法');
		}

		$user = db('admin_user')
		->where('username', $data['username'])
		->where('pwd', $data['password'])
		->find();

		if ($user) {
			session('admin', $user);
			$this->success('登录成功', url('index/index/index'));
		} else {
			$this->success('登录失败', url('index/user/login'));
		}
	}

	//用户退出
	public function logout()
	{
		//清空登录session
		session('admin', null);
		
		//  跳转到后台登录页面
		$this->redirect('index/user/login');
	}

	//用户列表页
	public function index()
	{
		$arr = db('user')->field('id, phone, email, name, style, lastlogintime, loginnum , status')
				->where('style', '>', 0)
				->paginate(5);
		$this->assign('arr', $arr);
		return $this->fetch();
	}

	//用户拉黑
	public function deFriend()
	{
		$arr  = request()->param();
		$id   = $arr['id'];
		$list = db("user")->where('id', $id)
				->update(['style'=>0]);
		if ($list) {
			return $this->success('拉黑成功', url('/index/user/index'));
		} else {
			return $this->error('拉黑失败', url('/index/user/index'));
		}
	}
	//用户升级权限
	public function upGrade()
	{
		//1.首先根据ID获取普通会员的信息
		$arr  = request()->param();
		$id   = $arr['id'];
		$arr1 = db('user')->field('phone, password, name, lastlogintime, style, loginnum')
				->where('id', $id)
				->find();
				
		$username = $arr1['phone'];
		$pwd 	  = $arr1['password'];
		$typeid   = $arr1['style'];
		$time 	  = $arr1['lastlogintime'];
		$num 	  = $arr1['loginnum'];
		$ip		  = $_SERVER['REMOTE_ADDR'];
		
  		
  		$status = 1;

  		$data = ['username'=>$username, 'pwd'=>$pwd, 'typeid'=>$typeid, 'lastlogin_time'=>$time, 'loginnum'=>$num, 'status'=>$status, 'lastlogin_ip'=>$ip];
  		//2.将所得的数据写入管理员表
  		$stmt = db('admin_user')->insert($data);

  		//3.对返回值进行判断是否升级成功
  		if ($stmt) {
  			
  			db("user")->where('id', $id)->update(['status'=>1]);

  			return $this->success('升级权限成功', url("index/AdminUser/index"));
  		} else {
  			return $this->error('升级权限失败', url('index/user/index'));
  		}
  		

		var_dump($stmt);
		exit;

	}


}
