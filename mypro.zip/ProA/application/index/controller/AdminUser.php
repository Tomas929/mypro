<?php
namespace app\index\controller;
use app\index\controller\Base;
use app\index\model\AdminUser as AdminUserModel;
/**
 *后台管理员
 */
class AdminUser extends Base
{
	
	//管理员列表
	public function index()
	{
		$arr = model('admin_user')->field('username, typeid, lastlogin_time, lastlogin_ip, loginnum, status, real_name, id')
			->where('status', 1)
			->paginate(5);

		$this->assign('list', $arr);
		return $this->fetch();
	}

	//删除管理员 
	public function deGrade()
	{
		$id = request()->param()['id'];

		$stmt = db('admin_user')
				->alias('a')
				->join('user u', 'a.username=u.phone')
				->where('a.id', $id)
				->update(['u.status'=>0, 'a.status'=>0]);
		
		if ($stmt) {
			return $this->success("取消成功", url("index/AdminUser/index"));
		} else {
			return $this->error('您的权限不够');
		}
	}
}