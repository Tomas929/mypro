<?php
namespace app\index\model;
use think\Model;

class AdminUser extends Model
{
	public function getTypeidAttr($value)
	{
		$status = [
			1 => '超级管理员',
			2 => '高级管理员',
			3 => '案例管理员'
		];
		
		return $status[$value];
	}
}
