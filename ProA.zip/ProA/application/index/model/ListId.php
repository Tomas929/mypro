<?php 
namespace app\index\model;
use think\Model;

class ListId extends Model
{
	public function getTree($pid = 0, $target = [])
	{
		$cs = $this->field('list_id,name,pid')
		      ->where('pid', 'eq', $pid)
		      ->where('level', 0)
			  ->select();
			  
		static $n = 1;
		
		foreach ($cs as $c) {
			$c->level = $n;

			$target[$c->list_id] = $c;

			$n++;
			$target = $this->getTree($c->list_id, $target);
			$n--;
		}
		return $target;
	}
}