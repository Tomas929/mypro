<?php 
namespace app\index\model;
use think\Model;

/**
 *
 */
class Project extends Model
{
	

	public function ListId()
	{
		return $this->belongsTo('list_id', 'list_id');
	}
	
	
	
}