<?php
namespace app\index\controller;
use app\index\controller\Base;
use app\index\model\Project as ProjectModel;
use app\index\model\ListId;
use think\Request;
/**
 * 
 */
class Project extends Base
{
	public function _initialize()
	{
		parent::_initialize();
		$cs = model('list_id')->getTree();
		$this->assign('cs', $cs);
	}
	
	public function index()
	{
		$list = model('project')->where('status', 1)
				->order('category desc')
				->paginate(10);

		$this->assign('list', $list);
		return $this->fetch();
	}

	public function add()
	{
		return $this->fetch();
	}

	public function doAdd()
	{
		$data = request()->param();
		$img  = request()->file();
		if ($img) {
				$certify = $img['certify']->move(ROOT_PATH.'public/static/upload');
				$cover = $img['cover']->move(ROOT_PATH.'public/static/upload');
			if ($cover || $certify) {

				$data['cover'] = $cover->getSaveName();
				$data['certify'] = $certify->getSaveName();
			}
		}


		$res = model('project')->save($data);
		if ($res) {
			$this->success("添加成功");
		} else {
			$this->error("添加失败");
		}
	}

	public function show()
	{
		$id = request()->param()['id'];
		$arr = model('project')->where('id', $id)
			 ->order('category asc')
			 ->select();
		$this->assign('arr', $arr);
		return $this->fetch();
	}

	public function del()
	{
		$id = request()->param()['id'];

		$data = model('project')->where('id', $id)->update(['status'=>0]);

		if ($data) {
			return $this->success('删除成功');
		} else {
			return $this->error('删除失败');
		}
	}

	public function edit()
	{
		$id = request()->param()['id'];
		$data = model('project')->where('id', $id)->find();
		//
		$this->assign('list', $data);
		return $this->fetch();
	}

	public function doEdit()
	{
		$data = request()->param();
		$img  = request()->file();

		if ($img) {
			$certify = $img['certify']->move(ROOT_PATH.'public/static/upload');
			$cover = $img['cover']->move(ROOT_PATH.'public/static/upload');
			if ($cover && $certify) {

				$data['cover'] = $cover->getSaveName();
				$data['certify'] = $certify->getSaveName();
			}
		}

		$id = $data['id'];
		array_pop($data);
		
		$res = model('project')->where('id', $id)->update($data);
		if ($res) {
			$this->success("更新成功");
		} else {
			$this->error("更新失败");
		}
	}

	public function doUp()
	{
		$category = request()->param()['category'];
		$id 	  = request()->param()['id'];
		$cate 	  = $category+1;

		model('project')->where('id', $id)->update(['category'=>$cate]);
	}

	public function doDown()
	{
		$category = request()->param()['category'];
		$id 	  = request()->param()['id'];
		$cate 	  = $category-1;
		if ($cate < 0) {
			$cate = 0;
		} else {
			$cate = $category-1;
		}
		
		$arr = model('project')->where('id', $id)->update(['category'=>$cate]);
		if ($arr) {
			return $this->redirect('index/project/index');
		} else {
			# code...
		}
		
	}

	public function doFrist()
	{
		$category = request()->param()['category'];
		$id 	  = request()->param()['id'];
		$cate 	  = $category-1;
		if ($cate < 0) {
			$cate = 0;
		} else {
			$cate = $category-1;
		}
		

		model('project')->where('id', $id)->update(['category'=>$category]);
	}

}