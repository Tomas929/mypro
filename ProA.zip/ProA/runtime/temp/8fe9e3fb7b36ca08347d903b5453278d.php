<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:75:"F:\Apache2.4\wamp\www\ProA\public/../application/index\view\user\index.html";i:1527754068;s:66:"F:\Apache2.4\wamp\www\ProA\application\index\view\public\base.html";i:1527661514;s:68:"F:\Apache2.4\wamp\www\ProA\application\index\view\public\topnav.html";i:1527656882;s:69:"F:\Apache2.4\wamp\www\ProA\application\index\view\public\leftnav.html";i:1527751725;}*/ ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>项目案例管理后台</title>

    <!-- Bootstrap core CSS -->
    <link href="/ProA/public/static/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="/ProA/public/static/css/dashboard.css" rel="stylesheet">
    
  </head>

  <body>

    <nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">项目案例管理后台</a>
    </div>
    <div id="navbar" class="navbar-collapse collapse">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#">Help</a></li>
        <li class="dropdown">
					<a href="#" data-toggle="dropdown">
						<span class="glyphicon glyphicon-user"></span>
						<span class="caret"></span>
					</a>
		  			<ul class="dropdown-menu">
<li><a href="#">
	<?php echo \think\Session::get('admin.username'); ?>
</a></li>
<li><a href="<?php echo url('index/user/logout'); ?>">退出</a></li>
		  			</ul>
				</li>
      </ul>
    </div>
  </div>
</nav>

    
    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 " ">
          <div class="panel-group" id="pgroup" style="margin-top: 50px;">
	<div class="panel <?php if(\think\Request::instance()->controller() == 'User' || \think\Request::instance()->controller() == 'AdminUser'): ?>panel-success<?php else: ?>panel-default<?php endif; ?>">
		<div class="panel-heading">
			<a href="#blog" data-toggle="collapse" data-parent="#pgroup">权限管理</a>
		</div>
		<?php if(\think\Session::get('admin.username') === 'admin'): ?>
		<div class="collapse <?php if(\think\Request::instance()->controller() == 'User' || \think\Request::instance()->controller() == 'AdminUser'): ?>in<?php endif; ?> panel-collapse" id="blog">
			<div class="panel-body">
				<ul class="list-group">
					<li class="list-group-item">
						<a href="<?php echo url('index/user/index'); ?>">会员列表</a>
					</li>
					<li class="list-group-item">
						<a href="<?php echo url('index/AdminUser/index'); ?>">管理员列表</a>
					</li>
				</ul>
			</div>
		</div>
		<?php endif; ?>
	</div>
	
	<div class="panel <?php if(\think\Request::instance()->controller() == 'ListId'): ?>panel-success<?php else: ?>panel-default<?php endif; ?>">
		<div class="panel-heading">
			<a href="#ListId" data-toggle="collapse" data-parent="#pgroup">
				分类管理
			</a>
		</div>
		<?php if(\think\Session::get('admin.username') === 'admin' || \think\Session::get('admin.username') === '10086'): ?>
		<div class="collapse <?php if(\think\Request::instance()->controller() == 'ListId'): ?>in<?php endif; ?> panel-collapse" id="ListId">
			<div class="panel-body">
				<ul class="list-group">
					<li class="list-group-item">
						<a href="<?php echo url('index/ListId/index'); ?>">分类列表</a>
					</li>
					<li class="list-group-item">
						<a href="<?php echo url('index/ListId/add'); ?>">分类添加</a>
					</li>

				</ul>
			</div>
		</div>
		<?php endif; ?>
	</div>

	<div class="panel <?php if(\think\Request::instance()->controller() == 'Project'): ?>panel-success<?php else: ?>panel-default<?php endif; ?>">
		<div class="panel-heading">
			<a href="#project" data-toggle="collapse" data-parent="#pgroup">
				 案例管理
			</a>
		</div>
		<?php if(\think\Session::get('admin.username') === 'admin' || \think\Session::get('admin.username') === '10010'): ?>
		<div class="collapse <?php if(\think\Request::instance()->controller() == 'Project'): ?>in<?php endif; ?> panel-collapse" id="project">
			<div class="panel-body">
				<ul class="list-group">
					<li class="list-group-item">
						<a href="<?php echo url('index/project/index'); ?>">案例列表</a>
					</li>
					<li class="list-group-item">
						<a href="<?php echo url('index/project/add'); ?>">案例添加</a>
					</li>
				</ul>
			</div>
		</div>
		<?php endif; ?>
	</div>

</div>
        </div>
        <div class="col-sm-9 ">
          
<h3>用户列表</h3>
<div class="table-responsive">
	<table class="table table-bordered table-condensed table-hover table-striped">
		<thead>
		
			<tr>
			  	<th>账号</th>
				<th>邮箱</th>
				<th>个性名称</th>
				<th>客户类别</th>
				<th>最后登陆时间</th>
				<th>登陆次数</th>
				<th>操作菜单</th>
			</tr>
		</thead>
		<tbody>
	<?php if(is_array($arr) || $arr instanceof \think\Collection || $arr instanceof \think\Paginator): $i = 0; $__LIST__ = $arr;if( count($__LIST__)==0 ) : echo "暂时没有数据" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
		<tr>
		<td><?php echo $vo['phone']; ?></td>
		<td><?php echo $vo['email']; ?></td>
		<td><?php echo $vo['name']; ?></td>
		<td><?php echo $vo['style']; ?></td>
		<td><?php echo $vo['lastlogintime']; ?></td>
		<td><?php echo $vo['loginnum']; ?></td>
		<td>
			<?php if($vo['status'] == 0): ?>
		<a href="<?php echo url('index/user/upGrade', ['id' => $vo['id']]); ?>" class="btn btn-success" onclick="return confirm('是否要给该用户升级?')">升级权限</a>
			<?php else: ?>
			<a href="#" class="btn btn-default" onclick="return confirm('该用户已经是后台管理员')">升级权限</a>
			<?php endif; ?>
		<a href="<?php echo url('index/user/deFriend', ['id' => $vo['id']]); ?>" class="btn btn-danger" onclick="return confirm('是否要拉黑该用户?')">拉黑</a>
		</td>
		</tr>
	<?php endforeach; endif; else: echo "暂时没有数据" ;endif; ?>
  		</tbody>
	</table>
</div>
<?php echo $arr->render(); ?>

        </div>
      </div>
    </div>

    <script src="/ProA/public/static/bootstrap/js/jquery-3.3.1.js" type="text/javascript" ></script>
    <script src="/ProA/public/static/bootstrap/js/bootstrap.min.js" type="text/javascript" ></script>
    
  </body>
</html>

