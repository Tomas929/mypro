<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:75:"F:\Apache2.4\wamp\www\ProA\public/../application/index\view\user\login.html";i:1527652069;}*/ ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>项目案例管理后台</title>
    <!-- Bootstrap core CSS -->
    <link href="/ProA/public/static/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="/ProA/public/static/css/signin.css" rel="stylesheet">
  </head>

  <body>

    <div class="container">

      <form action="<?php echo url('index/user/doLogin'); ?>" class="form-signin" method="post">
        <h2 class="form-signin-heading">项目案例管理后台</h2>
        <label for="inputEmail" class="sr-only">用户名</label>
        <input type="text" id="username" class="form-control" name="username" placeholder="请输入用户名" required autofocus>
        <label for="inputPassword" class="sr-only">密码</label>
        <input type="password" id="password" class="form-control" name="password" placeholder="请输入密码" required>
        <label for="inputEmail" class="sr-only">验证码</label>
        <input type="text" class="form-control" name="captcha" placeholder="请输入验证码" required >
        <img src="<?php echo captcha_src(); ?>" id="captcha" />
        
        <div class="checkbox">
          <label>
            <input type="checkbox" value="remember-me"> 七天免密登录
          </label>
        </div>
        <button class="btn btn-lg btn-primary btn-block" type="submit">登录</button>
      </form>

    </div> <!-- /container -->
    <script type="text/javascript">
    	var c = document.getElementById('captcha');
    	c.onclick = function(){
    		this.src = "<?php echo captcha_src(); ?>?rand="+Math.random();
    	}
    </script>
  </body>
</html>