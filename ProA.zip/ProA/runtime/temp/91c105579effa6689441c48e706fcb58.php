<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:77:"F:\Apache2.4\wamp\www\ProA\public/../application/index\view\project\edit.html";i:1527747847;s:66:"F:\Apache2.4\wamp\www\ProA\application\index\view\public\base.html";i:1527661514;s:68:"F:\Apache2.4\wamp\www\ProA\application\index\view\public\topnav.html";i:1527656882;s:69:"F:\Apache2.4\wamp\www\ProA\application\index\view\public\leftnav.html";i:1527732124;}*/ ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>项目案例管理后台</title>

    <!-- Bootstrap core CSS -->
    <link href="/ProA/public/static/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="/ProA/public/static/css/dashboard.css" rel="stylesheet">
    
  </head>

  <body>

    <nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">项目案例管理后台</a>
    </div>
    <div id="navbar" class="navbar-collapse collapse">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#">Help</a></li>
        <li class="dropdown">
					<a href="#" data-toggle="dropdown">
						<span class="glyphicon glyphicon-user"></span>
						<span class="caret"></span>
					</a>
		  			<ul class="dropdown-menu">
<li><a href="#">
	<?php echo \think\Session::get('admin.username'); ?>
</a></li>
<li><a href="<?php echo url('index/user/logout'); ?>">退出</a></li>
		  			</ul>
				</li>
      </ul>
    </div>
  </div>
</nav>

    
    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 " ">
          <div class="panel-group" id="pgroup" style="margin-top: 50px;">
	<div class="panel <?php if(\think\Request::instance()->controller() == 'User' || \think\Request::instance()->controller() == 'AdminUser'): ?>panel-success<?php else: ?>panel-default<?php endif; ?>">
		<div class="panel-heading">
			<a href="#blog" data-toggle="collapse" data-parent="#pgroup">权限管理</a>
		</div>
		<div class="collapse <?php if(\think\Request::instance()->controller() == 'User' || \think\Request::instance()->controller() == 'AdminUser'): ?>in<?php endif; ?> panel-collapse" id="blog">
			<div class="panel-body">
				<ul class="list-group">
					<li class="list-group-item">
						<a href="<?php echo url('index/user/index'); ?>">会员列表</a>
					</li>
					<li class="list-group-item">
						<a href="<?php echo url('index/AdminUser/index'); ?>">管理员列表</a>
					</li>
				</ul>
			</div>
		</div>
	</div>
	
	<div class="panel <?php if(\think\Request::instance()->controller() == 'ListId'): ?>panel-success<?php else: ?>panel-default<?php endif; ?>">
		<div class="panel-heading">
			<a href="#ListId" data-toggle="collapse" data-parent="#pgroup">
				分类管理
			</a>
		</div>
		<div class="collapse <?php if(\think\Request::instance()->controller() == 'ListId'): ?>in<?php endif; ?> panel-collapse" id="ListId">
			<div class="panel-body">
				<ul class="list-group">
					<li class="list-group-item">
						<a href="<?php echo url('index/ListId/index'); ?>">分类列表</a>
					</li>
					<li class="list-group-item">
						<a href="<?php echo url('index/ListId/add'); ?>">分类添加</a>
					</li>

				</ul>
			</div>
		</div>
	</div>

	<div class="panel <?php if(\think\Request::instance()->controller() == 'Project'): ?>panel-success<?php else: ?>panel-default<?php endif; ?>">
		<div class="panel-heading">
			<a href="#project" data-toggle="collapse" data-parent="#pgroup">
				 案例管理
			</a>
		</div>
		<div class="collapse <?php if(\think\Request::instance()->controller() == 'Project'): ?>in<?php endif; ?> panel-collapse" id="project">
			<div class="panel-body">
				<ul class="list-group">
					<li class="list-group-item">
						<a href="<?php echo url('index/project/index'); ?>">案例列表</a>
					</li>
					<li class="list-group-item">
						<a href="<?php echo url('index/project/add'); ?>">案例添加</a>
					</li>

				</ul>
			</div>
		</div>
	</div>

</div>
        </div>
        <div class="col-sm-9 ">
          
<h2>添加新闻</h2>
<form action="<?php echo url('index/Project/doEdit'); ?>" method="post" enctype="multipart/form-data">
	<div class="form-group">
		<label for="pid" class="control-label">所属分类:</label>
		<select name="list_id" class="form-control">
			<?php if(is_array($cs) || $cs instanceof \think\Collection || $cs instanceof \think\Paginator): $i = 0; $__LIST__ = $cs;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
			<option value="<?php echo $vo['list_id']; ?>">
				<?php echo str_repeat('--', $vo['level']); ?>
				<?php echo $vo['name']; ?>
			</option>
			<?php endforeach; endif; else: echo "" ;endif; ?>
		</select>
		<span class="help-block">请选择案例所属的分类</span>
	</div>
	<div class="form-group">
		<label for="title" class="control-label">项目名称:</label>
		<input type="text" name="title" id="title" value="<?php echo $list['title']; ?>" class="form-control"/>
		<span class="help-block">请输入项目名称,最长不超过255个字</span>
	</div>
	
	<div class="form-group">
		<label for="cover" class="control-label">封面图:</label>
		<input type="file" name="cover" id="cover" value="<?php echo $list['cover']; ?>" class="form-control"/>
		<span class="help-block">上传的封面图</span>
	</div>
	
	<div class="form-group">
		<label for="invest_mount" class="control-label">融资金额:</label>
		<input type="text" name="invest_mount" id="invest_mount" value="<?php echo $list['invest_mount']; ?>" class="form-control"/>
		<span class="help-block">请输入项目融资金额</span>
	</div>

	<div class="form-group">
		<label for="creat_time" class="control-label">结束时间:</label>
		<input type="text" name="creat_time" id="creat_time" value="<?php echo $list['creat_time']; ?>" class="form-control"/>
		<span class="help-block">请输入项目结束时间</span>
	</div>

	<div class="form-group">
		<label for="tags" class="control-label">标签:</label>
		<input type="text" name="tags" id="tags" value="<?php echo $list['tags']; ?>" class="form-control"/>
		<span class="help-block">请输入项目标签</span>
	</div>

	<div class="form-group">
		<label for="category" class="control-label">类型:</label>
		<input type="text" name="category" id="category" value="<?php echo $list['category']; ?>" class="form-control"/>
		<span class="help-block">请输入项目类型 必须是数字</span>
	</div>

	<div class="form-group">
		<label for="certify" class="control-label">企业证明:</label>
			<input type="file" name="certify" id="certify" value="<?php echo $list['certify']; ?>" class="form-control"/>
		<span class="help-block">请输入企业证明:</span>
	</div>

	<div class="form-group">
		<label for="intrduce" class="control-label">项目介绍:</label>
		<textarea name="intrduce" rows="5" cols="20"  id="ueditor"><?php echo $list['intrduce']; ?></textarea>
		<span class="help-block">请输入项目介绍</span>
	</div>
	<div class="form-group">
		<input type="hidden" name="status" value="0">
		<input type="hidden" name="id" value="<?php echo $list['id']; ?>">
		<input type="submit" value="添加" class="btn btn-primary"/>
		<input type="reset" value="取消" class="btn btn-default"/>
	</div>	
</form>


        </div>
      </div>
    </div>

    <script src="/ProA/public/static/bootstrap/js/jquery-3.3.1.js" type="text/javascript" ></script>
    <script src="/ProA/public/static/bootstrap/js/bootstrap.min.js" type="text/javascript" ></script>
    
<script src="/ProA/public/static/ueditor/ueditor.config.js" type="text/javascript" charset="utf-8"></script>
<script src="/ProA/public/static/ueditor/ueditor.all.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
	var ue = UE.getEditor('ueditor');
</script>

  </body>
</html>

